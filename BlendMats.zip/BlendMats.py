bl_info = {
    "name": "Roblox Color Exporter",
    "author": "You",
    "version": (1, 2, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Roblox",
    "description": "Exports object names and colors as a string for a Roblox Studio plugin",
    "category": "Import-Export",
}

import bpy
import re


LastReport = {
    "Valid": False,
    "Meshes": 0,
    "Entries": 0,
    "MultiColor": [],
    "NameConflicts": [],
    "NoMaterial": [],
}


def LinearToSrgb(Value):
    Value = max(0.0, min(1.0, float(Value)))
    if Value <= 0.0031308:
        Result = Value * 12.92
    else:
        Result = 1.055 * (Value ** (1.0 / 2.4)) - 0.055
    return int(round(Result * 255.0))


def CleanName(Name, StripSuffix):
    if StripSuffix:
        return re.sub(r"\.\d{3}$", "", Name)
    return Name


def FindMaterialColor(Material):
    if Material is None:
        return None
    if Material.use_nodes and Material.node_tree:
        for Node in Material.node_tree.nodes:
            if Node.type == "BSDF_PRINCIPLED":
                return Node.inputs["Base Color"].default_value[:3]
        for Node in Material.node_tree.nodes:
            if Node.type in {"EMISSION", "BSDF_DIFFUSE", "BSDF_GLOSSY", "BSDF_TOON"}:
                return Node.inputs["Color"].default_value[:3]
    return Material.diffuse_color[:3]


def ToRgb255(Color):
    if Color is None:
        return None
    return (LinearToSrgb(Color[0]), LinearToSrgb(Color[1]), LinearToSrgb(Color[2]))


def GetFaceCountsPerSlot(Obj):
    Counts = {}
    Mesh = Obj.data
    SlotTotal = len(Obj.material_slots)
    if SlotTotal == 0 or not hasattr(Mesh, "polygons"):
        return Counts
    for Polygon in Mesh.polygons:
        Index = Polygon.material_index
        if Index < SlotTotal:
            Counts[Index] = Counts.get(Index, 0) + 1
    return Counts


def GetUsedColors(Obj):
    Result = {}
    Counts = GetFaceCountsPerSlot(Obj)
    if len(Counts) == 0:
        return Result
    for Index in sorted(Counts.keys()):
        Material = Obj.material_slots[Index].material
        Color = ToRgb255(FindMaterialColor(Material))
        if Color is None:
            continue
        MaterialName = Material.name if Material else "Empty Slot"
        Existing = Result.get(Color)
        if Existing is None:
            Result[Color] = {"Faces": Counts[Index], "Materials": [MaterialName]}
        else:
            Existing["Faces"] += Counts[Index]
            Existing["Materials"].append(MaterialName)
    return Result


def GetObjectColor(Obj):
    Used = GetUsedColors(Obj)
    if len(Used) > 0:
        Best = None
        BestFaces = -1
        for Color in sorted(Used.keys()):
            if Used[Color]["Faces"] > BestFaces:
                BestFaces = Used[Color]["Faces"]
                Best = Color
        return Best

    Material = Obj.active_material
    if Material is None and len(Obj.material_slots) > 0:
        Material = Obj.material_slots[0].material
    Color = ToRgb255(FindMaterialColor(Material))
    if Color is not None:
        return Color
    return ToRgb255(Obj.color[:3])


def HasAnyMaterial(Obj):
    for Slot in Obj.material_slots:
        if Slot.material is not None:
            return True
    return False


def GatherObjects(Context):
    Scene = Context.scene
    if Scene.RobloxSelectedOnly:
        Source = list(Context.selected_objects)
    else:
        Source = list(Scene.objects)
    Objects = [Obj for Obj in Source if Obj.type == "MESH"]
    Objects.sort(key=lambda Item: Item.name)
    return Objects


def BuildEntries(Context):
    Scene = Context.scene
    Entries = []
    for Obj in GatherObjects(Context):
        Name = CleanName(Obj.name, Scene.RobloxStripSuffix)
        R, G, B = GetObjectColor(Obj)
        Entries.append((Name, R, G, B))
    return Entries


def BuildColorString(Context):
    Scene = Context.scene
    Entries = BuildEntries(Context)

    if Scene.RobloxExportMode == "ORDER":
        Lines = []
        for Index, Entry in enumerate(Entries):
            Lines.append("{}={},{},{}".format(Index + 1, Entry[1], Entry[2], Entry[3]))
        return ";".join(Lines)

    Lines = []
    Written = {}
    for Name, R, G, B in Entries:
        if Name in Written and Written[Name] == (R, G, B):
            continue
        Written[Name] = (R, G, B)
        Lines.append("{}={},{},{}".format(Name, R, G, B))
    return ";".join(Lines)


def RunCheck(Context):
    Objects = GatherObjects(Context)
    MultiColor = []
    NoMaterial = []

    for Obj in Objects:
        Used = GetUsedColors(Obj)
        if len(Used) > 1:
            Details = []
            for Color in sorted(Used.keys(), key=lambda Key: -Used[Key]["Faces"]):
                Details.append(
                    {
                        "Color": Color,
                        "Faces": Used[Color]["Faces"],
                        "Materials": Used[Color]["Materials"],
                    }
                )
            MultiColor.append({"Name": Obj.name, "Count": len(Used), "Details": Details})
        if not HasAnyMaterial(Obj):
            NoMaterial.append(Obj.name)

    Entries = BuildEntries(Context)
    Assigned = {}
    Conflicts = set()
    for Name, R, G, B in Entries:
        if Name in Assigned and Assigned[Name] != (R, G, B):
            Conflicts.add(Name)
        Assigned[Name] = (R, G, B)

    LastReport["Valid"] = True
    LastReport["Meshes"] = len(Objects)
    LastReport["Entries"] = 0 if len(Entries) == 0 else len(BuildColorString(Context).split(";"))
    LastReport["MultiColor"] = MultiColor
    LastReport["NameConflicts"] = sorted(Conflicts)
    LastReport["NoMaterial"] = NoMaterial
    return LastReport


def PrintCheckToConsole():
    for Item in LastReport["MultiColor"]:
        print("[Roblox Color Exporter] '{}' uses {} different colors:".format(Item["Name"], Item["Count"]))
        for Detail in Item["Details"]:
            print(
                "    {},{},{}  on {} face(s)  from: {}".format(
                    Detail["Color"][0],
                    Detail["Color"][1],
                    Detail["Color"][2],
                    Detail["Faces"],
                    ", ".join(Detail["Materials"]),
                )
            )
    for Name in LastReport["NoMaterial"]:
        print("[Roblox Color Exporter] '{}' has no material, falling back to object color".format(Name))


def BuildWarningText():
    Parts = []
    Multi = LastReport["MultiColor"]
    if len(Multi) > 0:
        Names = ", ".join(Item["Name"] for Item in Multi[:4])
        if len(Multi) > 4:
            Names += " and {} more".format(len(Multi) - 4)
        Parts.append("{} mesh(es) have more than one color: {}".format(len(Multi), Names))
    Conflicts = LastReport["NameConflicts"]
    if len(Conflicts) > 0:
        Parts.append("{} name(s) map to different colors: {}".format(len(Conflicts), ", ".join(Conflicts[:4])))
    return " | ".join(Parts)


class RobloxCheckColorsOperator(bpy.types.Operator):
    bl_idname = "roblox.check_colors"
    bl_label = "Check For Problems"
    bl_description = "Report meshes that use more than one color and names that collide"
    bl_options = {"REGISTER"}

    def execute(self, Context):
        RunCheck(Context)
        PrintCheckToConsole()
        Warning = BuildWarningText()
        if Warning != "":
            self.report({"WARNING"}, Warning)
        else:
            self.report({"INFO"}, "No problems found across {} mesh(es)".format(LastReport["Meshes"]))
        return {"FINISHED"}


class RobloxExportColorsOperator(bpy.types.Operator):
    bl_idname = "roblox.export_colors"
    bl_label = "Export Colors"
    bl_description = "Build the color string and copy it to the clipboard"
    bl_options = {"REGISTER"}

    def execute(self, Context):
        RunCheck(Context)
        if LastReport["Meshes"] == 0:
            self.report({"WARNING"}, "No mesh objects found")
            return {"CANCELLED"}

        Data = BuildColorString(Context)
        Context.window_manager.clipboard = Data

        TextBlock = bpy.data.texts.get("RobloxColors")
        if TextBlock is None:
            TextBlock = bpy.data.texts.new("RobloxColors")
        TextBlock.clear()
        TextBlock.write(Data)

        PrintCheckToConsole()
        Warning = BuildWarningText()
        if Warning != "":
            self.report({"WARNING"}, "Copied {} entries. {}".format(LastReport["Entries"], Warning))
        else:
            self.report({"INFO"}, "Copied {} entries to clipboard".format(LastReport["Entries"]))
        return {"FINISHED"}


class RobloxSelectProblemsOperator(bpy.types.Operator):
    bl_idname = "roblox.select_problems"
    bl_label = "Select Multi Color Meshes"
    bl_description = "Select every mesh that uses more than one color"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, Context):
        RunCheck(Context)
        Names = set(Item["Name"] for Item in LastReport["MultiColor"])
        if len(Names) == 0:
            self.report({"INFO"}, "No multi color meshes found")
            return {"CANCELLED"}

        bpy.ops.object.select_all(action="DESELECT")
        for Name in Names:
            Obj = Context.scene.objects.get(Name)
            if Obj is not None:
                Obj.select_set(True)
                Context.view_layer.objects.active = Obj

        self.report({"WARNING"}, "Selected {} multi color mesh(es)".format(len(Names)))
        return {"FINISHED"}


class RobloxSaveColorsOperator(bpy.types.Operator):
    bl_idname = "roblox.save_colors"
    bl_label = "Save Colors To File"
    bl_description = "Save the color string to a text file"

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filename_ext = ".txt"
    filter_glob: bpy.props.StringProperty(default="*.txt", options={"HIDDEN"})

    def execute(self, Context):
        Data = BuildColorString(Context)
        if Data == "":
            self.report({"WARNING"}, "No mesh objects found")
            return {"CANCELLED"}
        with open(self.filepath, "w", encoding="utf-8") as File:
            File.write(Data)
        self.report({"INFO"}, "Saved to {}".format(self.filepath))
        return {"FINISHED"}

    def invoke(self, Context, Event):
        if not self.filepath:
            self.filepath = "RobloxColors.txt"
        Context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}


class RobloxSplitByMaterialOperator(bpy.types.Operator):
    bl_idname = "roblox.split_by_material"
    bl_label = "Split Selected By Material"
    bl_description = "Separate selected meshes so every piece carries a single color"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(Cls, Context):
        return Context.mode == "OBJECT" and len(Context.selected_objects) > 0

    def execute(self, Context):
        Targets = [Obj for Obj in Context.selected_objects if Obj.type == "MESH"]
        if len(Targets) == 0:
            self.report({"WARNING"}, "No mesh objects selected")
            return {"CANCELLED"}

        Before = len(Context.scene.objects)
        bpy.ops.object.select_all(action="DESELECT")
        for Obj in Targets:
            Obj.select_set(True)
        Context.view_layer.objects.active = Targets[0]

        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.mesh.separate(type="MATERIAL")
        bpy.ops.object.mode_set(mode="OBJECT")

        After = len(Context.scene.objects)
        self.report({"INFO"}, "Created {} new object(s)".format(After - Before))
        return {"FINISHED"}


class RobloxRenameByColorOperator(bpy.types.Operator):
    bl_idname = "roblox.rename_by_color"
    bl_label = "Rename Objects By Color"
    bl_description = "Give every object a unique name based on its color so matching works"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, Context):
        Objects = GatherObjects(Context)
        if len(Objects) == 0:
            self.report({"WARNING"}, "No mesh objects found")
            return {"CANCELLED"}

        Groups = {}
        for Obj in Objects:
            Groups.setdefault(GetObjectColor(Obj), []).append(Obj)

        Index = 0
        for Key in sorted(Groups.keys()):
            Index += 1
            Counter = 0
            for Obj in Groups[Key]:
                Counter += 1
                Obj.name = "Color{}_{}".format(Index, Counter)

        LastReport["Valid"] = False
        self.report({"INFO"}, "Renamed {} objects into {} color groups".format(len(Objects), len(Groups)))
        return {"FINISHED"}


class RobloxColorPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_roblox_colors"
    bl_label = "Roblox Color Exporter"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox"

    def draw(self, Context):
        Layout = self.layout
        Scene = Context.scene

        Layout.prop(Scene, "RobloxExportMode", expand=True)

        Column = Layout.column(align=True)
        Column.prop(Scene, "RobloxSelectedOnly")
        Row = Column.row()
        Row.enabled = Scene.RobloxExportMode == "NAME"
        Row.prop(Scene, "RobloxStripSuffix")

        Layout.separator()
        Layout.operator("roblox.export_colors", icon="COPYDOWN")
        Layout.operator("roblox.save_colors", icon="FILE_TICK")

        Layout.separator()
        Layout.operator("roblox.check_colors", icon="VIEWZOOM")
        Layout.operator("roblox.rename_by_color", icon="SORTALPHA")

        MeshCount = 0
        for Obj in (Context.selected_objects if Scene.RobloxSelectedOnly else Scene.objects):
            if Obj.type == "MESH":
                MeshCount += 1

        Box = Layout.box()
        Box.label(text="Meshes: {}".format(MeshCount))

        if not LastReport["Valid"]:
            Box.label(text="Run a check to see problems", icon="INFO")
            return

        Box.label(text="Entries: {}".format(LastReport["Entries"]))

        Multi = LastReport["MultiColor"]
        if len(Multi) > 0:
            Alert = Box.column(align=True)
            Alert.alert = True
            Alert.label(text="{} mesh(es) have multiple colors".format(len(Multi)), icon="ERROR")
            for Item in Multi[:6]:
                Alert.label(text="    {}  ({} colors)".format(Item["Name"], Item["Count"]))
            if len(Multi) > 6:
                Alert.label(text="    and {} more".format(len(Multi) - 6))
            Box.operator("roblox.select_problems", icon="RESTRICT_SELECT_OFF")
            Box.operator("roblox.split_by_material", icon="MOD_EXPLODE")

        Conflicts = LastReport["NameConflicts"]
        if len(Conflicts) > 0:
            Alert = Box.column(align=True)
            Alert.alert = True
            Alert.label(text="{} name(s) share a color slot".format(len(Conflicts)), icon="ERROR")
            for Name in Conflicts[:6]:
                Alert.label(text="    {}".format(Name))

        NoMaterial = LastReport["NoMaterial"]
        if len(NoMaterial) > 0:
            Note = Box.column(align=True)
            Note.label(text="{} mesh(es) have no material".format(len(NoMaterial)), icon="INFO")
            for Name in NoMaterial[:4]:
                Note.label(text="    {}".format(Name))


Classes = (
    RobloxCheckColorsOperator,
    RobloxExportColorsOperator,
    RobloxSaveColorsOperator,
    RobloxSelectProblemsOperator,
    RobloxSplitByMaterialOperator,
    RobloxRenameByColorOperator,
    RobloxColorPanel,
)


def register():
    bpy.types.Scene.RobloxExportMode = bpy.props.EnumProperty(
        name="Mode",
        description="How the Roblox plugin should match parts",
        items=[
            ("NAME", "By Name", "Match each part by its name"),
            ("ORDER", "By Order", "Match by alphabetical position, ignoring names"),
        ],
        default="NAME",
    )
    bpy.types.Scene.RobloxSelectedOnly = bpy.props.BoolProperty(
        name="Selected Only",
        description="Only export objects that are currently selected",
        default=True,
    )
    bpy.types.Scene.RobloxStripSuffix = bpy.props.BoolProperty(
        name="Strip .001 Suffix",
        description="Remove Blender duplicate suffixes. Only safe when duplicates share one color",
        default=False,
    )
    for Cls in Classes:
        bpy.utils.register_class(Cls)


def unregister():
    for Cls in reversed(Classes):
        bpy.utils.unregister_class(Cls)
    del bpy.types.Scene.RobloxExportMode
    del bpy.types.Scene.RobloxSelectedOnly
    del bpy.types.Scene.RobloxStripSuffix


if __name__ == "__main__":
    register()
